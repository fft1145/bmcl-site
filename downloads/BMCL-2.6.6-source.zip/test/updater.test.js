'use strict';

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const updater = require('../src/core/updater');

test('更新白名单只允许启动器文件', () => {
  assert.strictEqual(updater.isPathAllowedForUpdate('main.js'), true);
  assert.strictEqual(updater.isPathAllowedForUpdate('renderer/app.js'), true);
  assert.strictEqual(updater.isPathAllowedForUpdate('src/core/launcher.js'), true);
  assert.strictEqual(updater.isPathAllowedForUpdate('launcher-version.json'), true);

  const forbidden = [
    'saves/level.dat',
    '.minecraft/options.txt',
    'options.txt',
    'mods/foo.jar',
    'versions/1.20.1/1.20.1.jar',
    'libraries/com/a.jar',
    'assets/objects/ab/cd',
    'logs/latest.log',
    'crash-reports/crash-1.txt',
    '../../Windows/system32/evil.dll',
    '/etc/passwd',
    'renderer/../../saves/x'
  ];
  for (const p of forbidden) {
    assert.strictEqual(updater.isPathAllowedForUpdate(p), false, '应拒绝 ' + p);
  }
});

test('版本号比较', () => {
  assert.strictEqual(updater.compareVersions('1.2.3', '1.2.2'), 1);
  assert.strictEqual(updater.compareVersions('v1.2.0', '1.2.0'), 0);
  assert.strictEqual(updater.compareVersions('1.0.1', '1.1'), -1);
  assert.strictEqual(updater.compareVersions('1.10', '1.9'), 1);
});

test('parseRelease 与 findUpdateAsset', () => {
  const release = updater.parseRelease({
    tag_name: 'v1.2.0',
    name: 'BMCL 1.2.0',
    body: 'notes',
    html_url: 'https://github.com/fft1145/BMCL/releases/tag/v1.2.0',
    assets: [{ name: 'fft1145-1.2.0-win.zip', browser_download_url: 'https://x/a.zip' }]
  });
  assert.strictEqual(release.version, '1.2.0');
  assert.strictEqual(updater.findUpdateAsset(release.assets).name, 'fft1145-1.2.0-win.zip');
});

test('findUpdateAsset 优先固定名 exe，其次兼容旧 exe / zip', () => {
  const fixed = updater.findUpdateAsset([
    { name: 'fft1145-1.2.0-portable.exe', url: 'https://x/old.exe' },
    { name: 'fft1145-portable.exe', url: 'https://x/fixed.exe' }
  ]);
  assert.strictEqual(fixed.name, 'fft1145-portable.exe');

  const legacyExe = updater.findUpdateAsset([
    { name: 'fft1145-1.1.0-portable.exe', url: 'https://x/legacy.exe' }
  ]);
  assert.strictEqual(legacyExe.name, 'fft1145-1.1.0-portable.exe');

  const zipOnly = updater.findUpdateAsset([
    { name: 'fft1145-1.0.0-win.zip', url: 'https://x/old.zip' }
  ]);
  assert.strictEqual(zipOnly.name, 'fft1145-1.0.0-win.zip');
});

test('checkForUpdate 发现更高版本', async () => {
  const fetchImpl = async () => ({
    ok: true,
    status: 200,
    json: async () => ({
      tag_name: 'v1.3.0',
      html_url: 'https://github.com/fft1145/BMCL/releases/tag/v1.3.0',
      body: '',
      assets: [{ name: 'fft1145-1.3.0-win.zip', browser_download_url: 'https://x/1.3.zip' }]
    })
  });
  const result = await updater.checkForUpdate({ currentVersion: '1.2.0', fetchImpl });
  assert.strictEqual(result.hasUpdate, true);
  assert.strictEqual(result.asset.url, 'https://x/1.3.zip');

  const same = await updater.checkForUpdate({ currentVersion: '1.3.0', fetchImpl });
  assert.strictEqual(same.hasUpdate, false);
});

test('parseManifest 解析备用线路清单', () => {
  const release = updater.parseManifest({
    version: '2.2.6',
    notes: 'fix login',
    pageUrl: 'https://bmcl26.netlify.app/#download',
    assets: [{ name: 'fft1145-portable.exe', url: 'https://x/a.exe' }]
  });
  assert.strictEqual(release.version, '2.2.6');
  assert.strictEqual(release.htmlUrl, 'https://bmcl26.netlify.app/#download');
  assert.strictEqual(updater.findUpdateAsset(release.assets).url, 'https://x/a.exe');
});

test('GitHub 直连失败时自动切换备用线路', async () => {
  const tried = [];
  const fetchImpl = async (url) => {
    tried.push(url);
    if (String(url).includes('api.github.com')) {
      throw new Error('HTTP 403');
    }
    return {
      ok: true,
      status: 200,
      json: async () => ({ version: '2.3.0', notes: 'mirror', assets: [] })
    };
  };
  const result = await updater.checkForUpdate({ currentVersion: '2.2.6', fetchImpl });
  assert.strictEqual(result.hasUpdate, true);
  assert.strictEqual(result.sourceId, 'raw');
  assert.ok(tried[0].includes('api.github.com'));
  assert.ok(tried[1].includes('launcher-version.json'));
});

test('preferMirror 时跳过 GitHub 直连', async () => {
  const tried = [];
  const fetchImpl = async (url) => {
    tried.push(url);
    return { ok: true, status: 200, json: async () => ({ version: '2.2.6', assets: [] }) };
  };
  const result = await updater.checkForUpdate({ currentVersion: '2.2.6', fetchImpl, preferMirror: true });
  assert.strictEqual(result.hasUpdate, false);
  assert.strictEqual(result.sourceId, 'raw');
  assert.ok(!tried.some((u) => u.includes('api.github.com')));
});

test('所有线路都失败时抛出汇总错误', async () => {
  const fetchImpl = async () => ({ ok: false, status: 502, json: async () => ({}) });
  await assert.rejects(
    () => updater.checkForUpdate({ currentVersion: '1.0.0', fetchImpl }),
    /所有更新线路都不可用/
  );
});

test('validateUpdateTree 拒绝包含游戏文件的更新包', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bmcl-up-'));
  fs.mkdirSync(path.join(dir, 'renderer'), { recursive: true });
  fs.mkdirSync(path.join(dir, 'saves'), { recursive: true });
  fs.writeFileSync(path.join(dir, 'renderer', 'app.js'), 'ok');
  fs.writeFileSync(path.join(dir, 'main.js'), 'ok');
  fs.writeFileSync(path.join(dir, 'saves', 'level.dat'), 'game data');

  const audit = updater.validateUpdateTree(dir);
  assert.strictEqual(audit.ok, false);
  assert.deepStrictEqual(audit.blocked, ['saves/level.dat']);
});

test('applyUpdateTree 在校验失败时整次中止', async () => {
  const src = fs.mkdtempSync(path.join(os.tmpdir(), 'bmcl-src-'));
  const appDir = fs.mkdtempSync(path.join(os.tmpdir(), 'bmcl-app-'));
  fs.writeFileSync(path.join(src, 'main.js'), 'new');
  fs.mkdirSync(path.join(src, 'saves'), { recursive: true });
  fs.writeFileSync(path.join(src, 'saves', 'level.dat'), 'evil');
  fs.writeFileSync(path.join(appDir, 'main.js'), 'old');

  await assert.rejects(updater.applyUpdateTree(src, appDir), /更新被拒绝/);
  assert.strictEqual(fs.readFileSync(path.join(appDir, 'main.js'), 'utf8'), 'old', '更新中止后原文件不能被修改');
});

test('applyUpdateTree 正常覆盖启动器文件', async () => {
  const src = fs.mkdtempSync(path.join(os.tmpdir(), 'bmcl-src-ok-'));
  const appDir = fs.mkdtempSync(path.join(os.tmpdir(), 'bmcl-app-ok-'));
  fs.writeFileSync(path.join(src, 'main.js'), 'new');
  fs.mkdirSync(path.join(src, 'renderer'), { recursive: true });
  fs.writeFileSync(path.join(src, 'renderer', 'app.js'), 'new app');
  fs.writeFileSync(path.join(appDir, 'main.js'), 'old');

  const result = await updater.applyUpdateTree(src, appDir);
  assert.strictEqual(result.updated, 2);
  assert.strictEqual(fs.readFileSync(path.join(appDir, 'main.js'), 'utf8'), 'new');
});

test('findUpdateAsset 识别实际打包产物名 Better-MC-Launcher.exe', () => {
  const asset = updater.findUpdateAsset([
    { name: 'Better-MC-Launcher.exe', url: 'https://x/bmcl.exe' },
    { name: 'source.zip', url: 'https://x/src.zip' }
  ]);
  assert.strictEqual(asset.name, 'Better-MC-Launcher.exe');
});

test('assetUrls 合并直链与镜像并去重', () => {
  const urls = updater.assetUrls({
    url: 'https://github.com/a.exe',
    mirrors: ['https://gh-proxy.com/https://github.com/a.exe', 'https://github.com/a.exe']
  });
  assert.deepStrictEqual(urls, [
    'https://github.com/a.exe',
    'https://gh-proxy.com/https://github.com/a.exe'
  ]);
});

test('downloadAsset 直链失败后改用镜像，并校验大小', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bmcl-dl-'));
  const dest = path.join(dir, 'update.exe');
  const data = Buffer.from('MZ' + 'x'.repeat(2046));
  const tried = [];
  const fetchImpl = async (url) => {
    tried.push(url);
    if (String(url).includes('github.com')) throw new Error('ECONNRESET');
    return {
      ok: true,
      status: 200,
      headers: { get: () => String(data.length) },
      arrayBuffer: async () => data
    };
  };
  const result = await updater.downloadAsset(
    { url: 'https://github.com/a.exe', mirrors: ['https://mirror/a.exe'], size: data.length },
    dest,
    { fetchImpl }
  );
  assert.strictEqual(result.url, 'https://mirror/a.exe');
  assert.strictEqual(fs.readFileSync(dest).length, data.length);
  assert.deepStrictEqual(tried, ['https://github.com/a.exe', 'https://mirror/a.exe']);
});

test('downloadAsset 大小不符时不会写入文件', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bmcl-dl-bad-'));
  const dest = path.join(dir, 'bad.exe');
  const fetchImpl = async () => ({
    ok: true,
    status: 200,
    headers: { get: () => '10' },
    arrayBuffer: async () => Buffer.from('short')
  });
  await assert.rejects(
    () => updater.downloadAsset({ url: 'https://x/a.exe', size: 100 }, dest, { fetchImpl }),
    /文件大小不符/
  );
  assert.strictEqual(fs.existsSync(dest), false);
});

test('checkDownloadAllowed：网络异常判定为被禁止，正常响应判定为可用', async () => {
  const failFetch = async () => {
    throw new Error('ECONNREFUSED');
  };
  const blocked = await updater.checkDownloadAllowed({ fetchImpl: failFetch, urls: ['https://x'] });
  assert.strictEqual(blocked.allowed, false);

  const okFetch = async () => ({ status: 200 });
  const allowed = await updater.checkDownloadAllowed({ fetchImpl: okFetch, urls: ['https://x'] });
  assert.strictEqual(allowed.allowed, true);
});

test('normalizeRelease：新旧两种前端传参都能找到更新包', () => {
  const assets = [
    { name: 'Better-MC-Launcher.exe', size: 100, url: 'https://example.com/a.exe' }
  ];
  // 旧版前端只传 release，asset 需要从 assets 里重新找回
  const legacy = updater.normalizeRelease({ version: '2.6.4', assets });
  assert.strictEqual(legacy.asset.name, 'Better-MC-Launcher.exe');

  // 新版前端传整份检查结果，asset 与 release 同级
  const result = { hasUpdate: true, asset: assets[0], release: { version: '2.6.4', assets: [] } };
  const modern = updater.normalizeRelease(result);
  assert.strictEqual(modern.version, '2.6.4');
  assert.strictEqual(modern.asset.url, 'https://example.com/a.exe');

  assert.strictEqual(updater.normalizeRelease(null), null);
});
